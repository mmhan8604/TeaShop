//左側功能列JSP滑鼠觸碰變顏色
// 按下後變藍字
$(".nav-link").on("click", function () {

    let nav_text = document.getElementsByClassName("nav-link")
    for (i = 0; i < nav_text.length; i++) {
        nav_text[i].style.color = ""
    }

    this.style.color = '#0074d9'
})

$("#btnGp .btn").on("click", function () {

    let btn = document.getElementsByClassName("sideBtn")
    let btnimg = $(".sideBtn img")

    for (i = 0; i < btn.length; i++) {
        btnimg[i].src = btnimg[i].src.replace("_blue.png", ".png")
        btn[i].style.borderColor = "";
        btn[i].style.borderWidth = "";
        btn[i].style.color = ""
    }

    this.getElementsByTagName("img")[0].src = this.getElementsByTagName("img")[0].src.replace(".png", "_blue.png")
    this.style.color = " #0074d9"
    this.style.borderColor = " #0074d9"
    this.style.borderWidth = "4px"
    //border-color: #0074d9;
    //border-width: 4px;
})

$("#upload").on("click", function () {
    $("#upTxt").html("儲存成功")//sucess function

})

$("#formSpace").on("click", function () {
    $("#upTxt").html("儲存資訊")//點表單時
})

